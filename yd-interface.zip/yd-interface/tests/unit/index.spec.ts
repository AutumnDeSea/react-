// test('Index.spec', () => {
//   expect(1 + 1).toEqual(2);
// });

import index from './index';
