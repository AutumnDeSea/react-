import * as index from './index';
// @ponicode
describe('index.default', () => {
  test('0', () => {
    let result: any = index.default(-5.48);
    expect(result).toMatchSnapshot();
  });

  test('1', () => {
    let result: any = index.default(-Infinity);
    expect(result).toMatchSnapshot();
  });
});
