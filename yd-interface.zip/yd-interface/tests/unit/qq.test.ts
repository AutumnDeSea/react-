import * as qq from './qq';
// @ponicode
describe('qq.index', () => {
  test('0', () => {
    let result: any = qq.index(0.0);
    expect(result).toBe(1);
  });

  test('1', () => {
    let result: any = qq.index(-Infinity);
    expect(result).toBe(-Infinity);
  });

  test('2', () => {
    let result: any = qq.index(Infinity);
    expect(result).toBe(Infinity);
  });

  test('3', () => {
    let result: any = qq.index(NaN);
    expect(result).toBe(NaN);
  });

  test('4', () => {
    let result: any = qq.index(-5.48);
    expect(result).toBe(-4.48);
  });
});
