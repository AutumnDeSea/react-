function yideng(num: number) {
  if (num == 0) {
    return 1;
  } else {
    return num + 1;
  }
}
