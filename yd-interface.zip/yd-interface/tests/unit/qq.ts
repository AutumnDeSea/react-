export function index(num: any) {
  if (num == 1) {
    return 1;
  } else {
    return num + 1;
  }
}
