import { useCallback, useEffect, useRef } from 'react';

export default function useMountedState() {
  const mountedRef = useRef<boolean>(false);
  //父组件给子组件传递 重新的创建句柄
  const get = useCallback(() => mountedRef.current, []);
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);
  return get;
}
