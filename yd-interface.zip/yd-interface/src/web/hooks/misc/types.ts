export type PromiseType<T> = T extends Promise<infer U> ? U : T;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type FunctionReturningPromise = (...args: any[]) => Promise<any>;
