import produce, { freeze, Draft } from 'immer';
import { useCallback, useState } from 'react';
//.d.ts 实现库
export type DraftFunction<S> = (draft: Draft<S>) => void;
export type Updater<S> = (arg: S | DraftFunction<S>) => void;
export type ImmerHook<S> = [S, Updater<S>];
export function useImmer<S = unknown>(initialValue: S | (() => S)): ImmerHook<S>;
//签名限制具体的实现 具体的实现参数不能超越签名 挂了
export function useImmer(initialValue: unknown) {
  const [val, updateValue] = useState(() =>
    freeze(typeof initialValue === 'function' ? initialValue() : initialValue, true)
  );
  return [
    val,
    useCallback(updater => {
      if (typeof updater === 'function') updateValue(produce(updater));
      else updateValue(freeze(updater));
    }, []),
  ];
}

// interface A {
//   log(str: string): string;
// }
// class B implements A {
//   log(str: string) {
//     return str;
//   }
// }
