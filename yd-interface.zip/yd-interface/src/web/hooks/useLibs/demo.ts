import useAsyncFn from '@hooks/useAsyncFn';
import { normalTask } from '@yideng/utils';

function useDemo() {
  //   const [task, updateTask] = atomWithImmer({ str: '' });
  const [state, doFetch] = useAsyncFn(async () => {
    const response = await normalTask;
    return response;
  });
  return [state, doFetch] as const;
}
export { useDemo };
