import { useEffect, useCallback } from 'react';
import { toggleService, DemoData } from '@yideng/utils';
import { useAtom } from 'jotai';
import { atomWithImmer } from 'jotai/immer';
const mangaAtomObj = atomWithImmer({
  loading: false,
  result: {} as DemoData,
});
export function useDemo() {
  const [query, setQuery] = useAtom(mangaAtomObj);
  const fn = useCallback(() => {
    toggleService.send('FETCH');
  }, []);
  useEffect(() => {
    toggleService.onTransition(state => {
      if (state.value === 'loading') {
        setQuery(draft => {
          draft.loading = true;
        });
      }
      setTimeout(() => {
        if (state.value === 'success') {
          setQuery(draft => {
            draft.loading = false;
            draft.result = (state.context as any).user;
          });
        }
      }, 3000);
    });
  }, []);
  return [query, fn] as const;
}
