import { useEffect } from 'react';
import useAsyncFn from './useAsyncFn';
import { FunctionReturningPromise } from './misc/types';

export default function useAsync<T extends FunctionReturningPromise>(fn: T) {
  const [state, callback] = useAsyncFn(fn, {
    loading: true,
  });
  useEffect(() => {
    callback();
  }, [callback]);
  return [state, fn];
}

// const Demo = ({url}) => {
//     const state = useAsync(async () => {
//       const response = await fetch(url);
//       const result = await response.text();
//       return result
//     }, [url]);

//     return (
//       <div>
//         {state.loading
//           ? <div>Loading...</div>
//           : state.error
//             ? <div>Error: {state.error.message}</div>
//             : <div>Value: {state.value}</div>
//         }
//       </div>
//     );
//   };
