import { useCallback, useRef } from 'react';
import { FunctionReturningPromise, PromiseType } from './misc/types';
import { useImmer } from './useImmer';
import useMountedState from './useMountedState';
type AsyncState<T> =
  | {
      loading: boolean;
      error?: undefined;
      value?: undefined;
    }
  | {
      loading: true;
      error?: Error | undefined;
      value?: T;
    }
  | {
      loading: false;
      error: Error;
      value?: undefined;
    }
  | {
      loading: false;
      error?: undefined;
      value: T;
    };

// type T0 = ReturnType<() => string>;
// const fn = async()=>{
//   return 222;
// }
// type T0 = ReturnType<typeof fn>;
//返回元组里对应的value
type StateFromFunctionReturningPromise<T extends FunctionReturningPromise> = AsyncState<
  PromiseType<ReturnType<T>>
>;

//返回元组类型
type AsyncFnReturn<T extends FunctionReturningPromise> = [StateFromFunctionReturningPromise<T>, T];

export default function useAsyncFn<T extends FunctionReturningPromise>(
  fn: T,
  initialState: StateFromFunctionReturningPromise<T> = { loading: false }
): AsyncFnReturn<T> {
  //useImmer 封装了 immer.js 哨兵变量
  const lastCallId = useRef(0);
  const [state, set] = useImmer(initialState);
  const isMounted = useMountedState();
  //输入+输出
  // const hooksDeps = [fn, isMounted, state.loading];
  const callback = useCallback(
    (...args: Parameters<T>) => {
      const callId = ++lastCallId.current;
      if (!state.loading) {
        //不管什么状态都要让组件处于loading状态
        set(preState => ({ ...preState, loading: true }));
      }
      console.log('callId-->' + callId, 'useRef-->' + lastCallId.current);
      return fn(...args).then(
        value => {
          if (isMounted() && callId === lastCallId.current) {
            set(draft => {
              draft.loading = false;
              draft.value = value;
            });
          }
          return value;
        },
        error => {
          if (isMounted() && callId === lastCallId.current) {
            set(draft => {
              draft.loading = false;
              draft.error = new Error('数据请求失败');
            });
          }
          return error;
        }
      ) as ReturnType<T>;
    },
    [fn, isMounted, set, state.loading]
  );
  return [state, callback as unknown as T];
}
