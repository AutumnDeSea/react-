import { atom } from 'jotai';
const countAtom = atom<number>(0);
export { countAtom };
