import './index.css';
import React from 'react';
import { Link } from 'react-router-dom';
import logo from '@assets/images/solv-logo.png';

const SolvHeader = () => {
  return (
    <header>
      <div className="h-[80px] solvheader text-[16px] p-header flex items-center backdrop-blur justify-between">
        <div>
          <img className="h-10" src={logo} alt="logo" />
        </div>
        <div>
          <Link className="text-purple-600" to="/">
            主页
          </Link>
          <Link to="/demo/123456">Demo页面</Link>
          <Link to="/demo/solv">Solv状态</Link>
        </div>
      </div>
    </header>
  );
};
export default SolvHeader;
