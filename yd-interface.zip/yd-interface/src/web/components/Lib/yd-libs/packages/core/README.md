# `core`

> TODO: description

## Usage

```
const core = require('core');

// TODO: DEMONSTRATE API
```
