# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.2](https://github.com/lgwebdream/yideng-libs/compare/@yideng/core@1.0.1...@yideng/core@1.0.2) (2022-02-12)

**Note:** Version bump only for package @yideng/core





## 1.0.1 (2022-02-12)

**Note:** Version bump only for package @yideng/core
