import React, { FC } from 'react';

const Loading: FC = () => (
  <>
    <div>
      <span>加载中...</span>
    </div>
  </>
);
export default Loading;
