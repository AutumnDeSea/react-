import React, { FC } from 'react';

const PageNotFoundView: FC = () => (
  <>
    <div>
      <span>404</span>
    </div>
  </>
);
export default PageNotFoundView;
