import React, { memo, useEffect, useState } from 'react';
import { useCustomEvent, useEmitter, useListener } from 'react-custom-events-hooks';
import { toggleService, DemoData } from '@yideng/utils';

const Demo = () => {
  const [flag, updateFlag] = useState(0);
  const fn = () => {
    toggleService.send('TOGGLE');
  };
  // 坏的 bad
  // updateFlag(Math.random().toString());

  // toggleService.onTransition(state => {
  //   updateFlag(state.value);
  // });
  useListener('ctoggle', (e: CustomEvent<DemoData>) => {
    console.log('xxxxx', e.detail.userId);
    updateFlag(e.detail.userId);
  });

  // useEffect(() => {
  //   toggleService.onTransition(state => {
  //     updateFlag(state.value);
  //   });
  // }, []);

  return (
    <div>
      <h1> 测试值 {flag}</h1>
      <button onClick={() => fn()}>改变三方libs数据</button>
    </div>
  );
};
// const Demo = () => {
//   const [query, fn] = useDemo();
//   return (
//     <div>
//       {query.loading ? <div>Loading...</div> : <h1> 测试值 {query.result.userId}</h1>}

//       <button onClick={() => fn()}>改变三方libs数据</button>
//     </div>
//   );
// };
Demo.whyDidYouRender = true;
export default memo(Demo);
