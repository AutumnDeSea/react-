// import { useAtom } from 'jotai';
import React, { memo } from 'react';
import { useDemo } from '@hooks/useLibs/demo';
// import { useParams } from 'react-router-dom';
// import { countAtom } from '@states/common';
// import ChildMemo from './Child';
// // import { useImmer } from '@hooks/useImmer';
// import { atomWithImmer, useImmerAtom } from 'jotai/immer';
// const mangaAtomObj = atomWithImmer({ a: 1 });

// type DemoRouterProps = { id: string };
// type YdPros = {
//   msg: string;
// };
// const Demo = (props: YdPros) => {
//   const { msg } = props;
//   // const [count, setCount] = useState({ a: 1 });
//   // const [count, setCount] = useImmer({ a: 1 });
//   const [count, setCount] = useImmerAtom(mangaAtomObj);
//   const handleSetCount = () => {
//     setCount(draft => {
//       draft.a = draft.a;
//     });
//   };
//   const [num, setNum] = useAtom(countAtom);

//   console.log('msg: ', msg);
//   console.log(`爹 re-render`);
//   const { id } = useParams<DemoRouterProps>();
//   // setCount({ a: 1 });
//   return (
//     <>
//       <h1>
//         接受参数🚗
//         {id}
//         🚗
//       </h1>
//       <ChildMemo />
//       <button onClick={handleSetCount}>触发额外变化: {count.a} </button>
//       <br /> <br />
//       <span>公用组件 {num}</span>
//       <p>
//         <button
//           className="text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded text-lg"
//           onClick={() => setNum(Math.random())}
//         >
//           全局数据变化
//         </button>
//       </p>
//     </>
//   );
// };
// // const Demo = inject(Test, { msg: '老袁' });
// Demo.whyDidYouRender = true;
// export default memo(Demo);
const Demo = () => {
  const [state, doFetch] = useDemo();

  return (
    <div>
      {state.loading ? (
        <div>Loading...</div>
      ) : state.error ? (
        <div>Error: {state.error.message}</div>
      ) : (
        <div>Value: {state.value?.userId}</div>
      )}
      <button onClick={() => doFetch()}>Start loading</button>
    </div>
  );
};
export default memo(Demo);
