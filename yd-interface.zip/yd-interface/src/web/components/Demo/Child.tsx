import React, { memo } from 'react';

// export default memo((props: { count: number }) => {
//   console.log(`--- re-render ---`);
//   return (
//     <div>
//       {/* <p>step is : {props.step}</p> */}
//       {/* <p>count is : {props.count}</p> */}
//       <p>number is : {props.count}</p>
//     </div>
//   );
// });

export default memo(() => {
  console.log(`--- re-render ---`);
  return (
    <div>
      <input className="el-input__inner" type="text" />
      <p>子组件</p>
    </div>
  );
});
