import React from 'react';
import { useDemo } from '@hooks/useLibs/demo';

const Toggler = () => {
  const [state, doFetch] = useDemo();
  // const data = state.value as unknown as { str: string };
  return (
    <div>
      {state.loading ? (
        <div>Loading...</div>
      ) : state.error ? (
        <div>Error: {state.error.message}</div>
      ) : (
        <div>Value: {state.value?.str}</div>
      )}
      <button onClick={() => doFetch()}>Start loading</button>
    </div>
  );
};
export { Toggler };
