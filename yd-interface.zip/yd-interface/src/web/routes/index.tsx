import MainView from '@components/MainView';
import PageNotFoundView from '@components/Lib/PageNotFoundView';
import React, { lazy, Suspense } from 'react';
import { Navigate, RouteObject } from 'react-router-dom';
import MainLayout from '@pages/MainLayout';
// import DemoLayout from '@pages/DemoLayout';
import Loading from '@components/Lib/Loading';
const Layout = () => (
  <Suspense fallback={<Loading />}>
    <MainLayout />
  </Suspense>
);

const Demo = lazy(() => import('@components/Demo'));
const Routes: RouteObject[] = [];
const mainRoutes = {
  path: '/',
  element: <Layout />,
  children: [
    { path: '*', element: <Navigate to="/404" /> },
    { path: '/', element: <MainView /> },
    { path: '404', element: <PageNotFoundView /> },
  ],
};

const demoRoutes = {
  path: 'demo',
  // element: (
  //   <Suspense fallback={<Loading />}>
  //     <DemoLayout />
  //   </Suspense>
  // ),
  element: <Layout />,
  children: [
    { path: '*', element: <Navigate to="/404" /> },
    { path: ':id', element: <Demo /> },
  ],
};
Routes.push(mainRoutes, demoRoutes);
export default Routes;
