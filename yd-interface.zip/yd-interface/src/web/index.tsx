import './wdyr';
import React from 'react';
import ReactDOM from 'react-dom';
import PageErrorFallback from '@components/Lib/BeautifulError';
import ErrorBoundary from '@components/Lib/ErrorBoundary';
import { BrowserRouter } from 'react-router-dom';
import App from '@pages/App';
import './style.css';
ReactDOM.render(
  <ErrorBoundary fallbackRender={PageErrorFallback}>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </ErrorBoundary>,
  document.getElementById('app')
);
