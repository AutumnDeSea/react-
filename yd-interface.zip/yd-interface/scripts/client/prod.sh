#webpack的上线环境
webpack --mode production
