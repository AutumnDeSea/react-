import React from 'react';
import './App.css';
import { Button } from './components/Button/Button';

function App() {
  return (
    <>
      <Button label="Hello" btnType="link" href="http://www.baidu.com" />
      <hr />
      <h1 className="text-3xl font-bold underline">Hello world!</h1>
    </>
  );
}

export default App;
