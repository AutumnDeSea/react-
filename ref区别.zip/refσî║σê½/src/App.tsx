import React, { createRef, useRef, useState } from 'react';
import './App.css';

const AndCreateRefDiffrent = () => {
  const [renderIndex, setRenderIndex] = useState(0);
  const a = useRef<number>(0);
  const refFromCreateRef = createRef<number>();
  // a.current = renderIndex;
  if (!a.current) {
    a.current = renderIndex;
  }
  if (!refFromCreateRef.current) {
    (refFromCreateRef as any).current = renderIndex;
  }
  return (
    <div>
      <p>当前state {renderIndex}</p>
      <p>当前use Ref {a.current}</p>
      <p>当前的CreateRef {refFromCreateRef.current} </p>
      <button
        onClick={() => {
          setRenderIndex((prev) => prev + 1);
        }}
      >
        增加render index
      </button>
    </div>
  );
};

function App() {
  return (
    <div className="App">
      <AndCreateRefDiffrent />
    </div>
  );
}

export default App;
