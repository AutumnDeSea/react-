'use strict';

const core = require('..');

describe('core', () => {
    it('needs tests');
});
