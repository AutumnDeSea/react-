'use strict';

const data: string = '我是core🐻---';
export default data;
